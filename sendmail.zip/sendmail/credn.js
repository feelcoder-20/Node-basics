const user = 'use your email id';
const pass = 'use your password'


exports.user = user
exports.pass = pass