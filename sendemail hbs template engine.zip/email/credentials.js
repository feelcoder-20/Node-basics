const email = "use your emailid"
const pass = "use your password"

exports.email = email
exports.pass = pass