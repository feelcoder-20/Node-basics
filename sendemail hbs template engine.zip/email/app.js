const express = require("express")
const credn = require("./credentials")
const nodemailer = require("nodemailer");
const app = express()


const publicfile = express.static("public")
app.use(publicfile)
app.use(express.urlencoded())
app.set("view engine", "hbs")


app.get("/", function(req, res) {
    res.render("index")
})
app.post("/send", function(req, res) {

    var emailto = req.body.email
    var email2 = req.body.email2
    var subjectto = req.body.subject
    var message = req.body.message
    console.log(subjectto + ' ' + message + ' ' + emailto)
    let transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: credn.email, // generated ethereal user
            pass: credn.pass // generated ethereal password
        }
    }); //Sending mail to provided emailid
    let info = transporter.sendMail({
            from: 'feelcoderera@gmail.com', // sender address
            to: [emailto,
                email2
            ], // list of receivers
            subject: subjectto, // Subject line
            html: "<h1 style='background-color: rgb(117, 175, 167);padding:50px;width:600px;border-radius: 10px;'>" + message + "</h1>"
        },
        function(error) {
            if (error)
                console.log(error)
            else
                res.render("index", {
                    m: "Email sent successfully!"
                })
        })




})
app.listen(3004)